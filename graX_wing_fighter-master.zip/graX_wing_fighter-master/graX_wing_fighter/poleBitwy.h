#pragma once
class poleBitwy
{
public:
	poleBitwy();
	~poleBitwy();
	
};

